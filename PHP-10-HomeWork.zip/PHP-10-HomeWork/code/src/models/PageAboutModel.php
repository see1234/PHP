<?php

namespace app\models;

class PageAboutModel extends BaseModel
{
    public string $phone = '+7 (999) 999 99-99';
    public string $address = 'г. Москва, ул. Придуманная 1';
}